<?php 
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die ("Connection Failed: " . $conn->connect_error);
    }

    // Validate input parameters
    if (!isset($_GET['product_id']) || !isset($_GET['user_id'])) {
        die("Invalid request. Please go back and select a product");
    }

    $product_id = $_GET['product_id'];
    $user_id = $_GET['user_id'];

    // Retrieve the product details
    $product_query = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $product_query-> bind_param("i", $product_id);
    $product_query-> execute();
    $product_result = $product_query->get_result();
    $product = $product_result->fetch_assoc();

    if (!$product) {
        die("Product not found.");
    }
    
    $product_query->close();
    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Summary | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="ordersummary.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk,</h1> <h1><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></h1>
        </div>
        <ul>
            <li><a href="store.php"><img src="assets/i_tag.svg"> Product</a></li>
            <li><a href="orders.php" class="disabled"><img src="assets/i_shopping-cart.svg"> Your Cart</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <div class="tablecontainer">
                <h3>Order Summary Details</h3>
                <?php
                    // Ensures the image path is correct
                    $image_path = "upload/" . htmlspecialchars($products['image']);
                    if (!file_exists($image_path) || empty($product['image'])) {
                        $image_path = "uploads/preview.png";// Fallback image / Default
                    }
                ?>
                <img src="<?php echo $image_path; ?>" alt="<?php echo htmlspecialchars($product('name')) ?>">

                <p><strong>Type:</strong> <?php echo htmlspecialchars($product['name']) ?></p>
                <p><strong>Price:</strong> <?php echo htmlspecialchars($prodcut['price'], 2) ?></p>

                <h3>Customer Details</h3>
                <form action="orderfinal.php" method="POST">
                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_id); ?>">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">

                    <label for="username">Name:</label>
                    <p name="username"><?php echo htmlspecialchars($username); ?></p>

                    <label for="full_name">Full Name: </label>
                    <input type="text" id="full_name" name="full_name" required>

                    <label for="address">Address: </label>
                    <input type="text" id="address" name="address" required>

                    <label for="contact">Contact: </label>
                    <input type="text" id="contact" name="contact" required>

                    <label for="payment_method">Payment Method: </label>
                    <select name="payment_method" id="payment_method">
                        <option value="Credit Card">Credit Card</option>
                        <option value="PayPal">PayPal</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Cash on Delivery">Cash on Delivery</option>
                    </select>

                    <button type="submit">Confirm Order</button>
                </form>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>