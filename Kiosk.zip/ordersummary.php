<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->connect_error);
    }

    // Checks for the form submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_id = $_POST["user_id"];
        $product_id = $_POST["product_id"];
        $full_name = $_POST["full_name"];
        $address = $_POST["address"];
        $contact = $_POST["contact"];
        $payment_method = $_POST["payment_method"];

        // Retrieve the product info
        $product_query = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $product_query->bind_param("i", $product_id);
        $product_query->execute();
        $product_result = $product_query->get_result();
        $product = $product_result->fetch_assoc();

        if (!$product) {
            die("Product not found.");
        }

        // Insert into database
        $stmt = $conn->prepare("INSERT INTO orders(user_id, product_id, full_name, address, contact, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissss", $user_id, $product_id, $full_name, $address, $contact, $payment_method);
        $stmt->execute();
        $stmt->close();
    } else {
        die ("Invalid request");
    }

    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Summary | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="ordersummary.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk,</h1> <h1><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></h1>
        </div>
        <ul>
            <li><a href="store.php"><img src="assets/i_tag.svg"> Product</a></li>
            <li><a href="orders.php" class="disabled"><img src="assets/i_shopping-cart.svg"> Your Cart</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <div class="main-container">
                <h2>Thank you for purchasing, <?php echo htmlspecialchars("$full_name"); ?>!</h2>
                <p>Your purchased product has been placed successfully</p>

                <div>
                    <?php
                    // fixed image path
                    $image_path = "uploads/" . htmlspecialchars($product['image']);
                    if (!file_exists($image_path) || empty($product['image'])) {
                        $image_path = "uploads/preview.png";
                    }
                    ?>
                    <img src="<?php echo $image_path; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">

                    <p><strong>Product: </strong><?php echo htmlspecialchars($product['name']); ?></p>
                    <p><strong>Price: </strong><?php echo htmlspecialchars(number_format($product['price'], 2)); ?></p>
                    <p><strong>Shipping Address: </strong><?php echo htmlspecialchars($address); ?></p>
                    <p><strong>Contact Number: </strong><?php echo htmlspecialchars($contact); ?></p>
                    <p><strong>Payment Method: </strong><?php echo htmlspecialchars($payment_method); ?></p>
                    
                </div>

            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>