<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->connect_error);
    }

    // Checks if the user has logged in
    if (!isset($_SESSION['username'])) {
        header('Location: form.php');
        exit();
    }

    // Get the user_id from session
    $user_id = $_SESSION['user_id'];

    // fetch the products from database
    $result = $conn->query("SELECT * FROM products");

    if (!$result) {
        die("Query Failed: " . $conn->error);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="store.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk,</h1> <h1><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></h1>
        </div>
        <ul>
            <li><a href="store.php" class="disabled"><img src="assets/i_tag.svg"> Product</a></li>
            <li><a href="orders.php"><img src="assets/i_shopping-cart.svg"> Your Cart</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>

    <main>
        <section>
            <div class="maincontainer">
                <h1>Products</h1>
                <?php while ($row = $result->fetch_assoc()): ?>
                <div class="product">
                    <h2><?php echo htmlspecialchars($row['name']); ?></h2>
                    <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                    <p class="price">&#8369;<?php echo number_format($row['price'], 2); ?></p>
                    <button type="button" onclick="location.href='orderform.php?product_id=<?php echo $row['id']; ?>&user_id=<?php echo $user_id; ?>';">add to cart</button>
                </div>
                <?php endwhile; ?>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>
<?php $conn->close(); ?>