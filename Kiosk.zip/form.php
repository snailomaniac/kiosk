<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="form.css">
</head>
<body>
    <!-- Login Form -->
    <div class="login">
        <form action="login.php" method="post" id="login-form" class="formbox active">
            <h1>Log In</h1>
            
            <!-- Display error message if login credentials are invalid -->
            <?php if (isset($_GET['error']) && $_GET['error'] === 'invalid_credentials' && $_SERVER['REQUEST_METHOD'] === 'GET'): ?>
                <p style="color: red;margin: 0;">Invalid username or password.<br> Please try again.</p><br>
            <?php endif; ?>

            <!-- Username Input -->
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br>

            <!-- Password Input -->
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>

            <!-- Ask user to register if they don't have an account -->
            <p>Don't have an account? <a href="#" onclick="showForm('register-form')">Register</a></p>

            <!-- Submit Button -->
            <input type="submit" value="Login">
        </form>
    </div>

    <!-- Register Form -->
    <div class="register">
        <form action="register.php" method="post" id="register-form" class="formbox">
            <h1>Register</h1>

            <!-- Username Input -->
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <br>

            <!-- Password Input -->
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <br>

            <!-- Ask user to login if they already have an account -->
            <p>Already have an account? <a href="#" onclick="showForm('login-form')">Log in</a></p>

            <!-- Submit Button -->
            <input type="submit" value="Register">
        </form>
    </div>
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>