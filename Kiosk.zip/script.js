function showForm(formId) {
    document.querySelectorAll('.formbox').forEach(form => form.classList.remove('active'));
    document.getElementById(formId).classList.add('active');
    // Hide the other form
    if (formId === 'login-form') {
        document.querySelector('.register').style.display = 'none';
        document.querySelector('.login').style.display = 'block';
    } else {
        document.querySelector('.login').style.display = 'none';
        document.querySelector('.register').style.display = 'block';
    }
}