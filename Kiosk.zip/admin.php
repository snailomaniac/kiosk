<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk</h1>
        </div>
        <ul>
            <li><a href="admin.php" class="disabled"><img src="assets/i_cpu.svg"> Admin Panel</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <h1>Admin Panel</h1>
            <div class="maincontainer">
                <div class="sectioncontainer">
                    <h2>Account Management</h2>
                    <p>View, add, edit, or delete user accounts.</p>
                    <a href="manageaccount.php">Manage Accounts</a>
                </div>

                <div class="sectioncontainer">
                    <h2>Order Management</h2>
                    <p>View, and proccess customers orders.</p>
                    <a href="manageorders.php">Manage Orders</a>
                </div>
                
                <div class="sectioncontainer">
                    <h2>Product Management</h2>
                    <p>View, updates, or remove products.</p>
                    <a href="manageproducts.php">Manage Products</a>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>