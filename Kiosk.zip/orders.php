<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->connect_error);
    }

    // Checks if the user has logged in
    if (!isset($_SESSION['username'])) {
        header('Location: form.php');
        exit();
    }

    // Get the user_id from session
    $user_id = $_SESSION['user_id'];

    $order_query = $conn->prepare("
        SELECT orders.id, products.image, products.name AS product_name
        FROM orders
        JOIN products ON orders.product_id = products.id
        WHERE orders.user_id = ?
        ORDER BY orders.id DESC
    ");
    $order_query->bind_param("i", $user_id);
    $order_query->execute();
    $order_result = $order_query->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="orders.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk,</h1> <h1><span><?php echo htmlspecialchars($_SESSION['username']); ?></span></h1>
        </div>
        <ul>
            <li><a href="store.php"><img src="assets/i_tag.svg"> Product</a></li>
            <li><a href="orders.php" class="disabled"><img src="assets/i_shopping-cart.svg"> Your Cart</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <div class="tablecontainer">
                <table>
                    <tr>
                        <th width="16px">id</th>
                        <th width="200px">Image</th>
                        <th width="300px">Product</th>
                        <th width="400px">Manage</th>
                    </tr>
                    <?php while ($row = $order_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['id']); ?></td>
                        <td><img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Product Image" width="100"></td>
                        <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                        <td><a href="manage_order.php?order_id=<?php echo $row['id']; ?>">Manage</a></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>

<?php 
    $order_query->close();
    $conn->close();
?>