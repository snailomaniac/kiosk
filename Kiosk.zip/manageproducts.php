<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->connect_error);
    }

    // Add Products
    if (isset($_POST['add_product'])) {
        $name = $_POST['name'];
        $price = $_POST['price'];
        $image = $_FILES['image']['name'];
        $target = "uploads/" . basename($image);
        
        // Checks the dir
        if (!is_dir("uploads")) {
            mkdir("uploads", 0777, true);
        }

        // Uploads the file from dir to database?
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $stmt = $conn->prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
            $stmt->bind_param("sds", $name, $price, $image);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "<script>alert('Failed to upload image.');</script>";
        }
    }

    // Delete Products
    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];

        // Retrieve the location of the image from dir
        $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($image);
        $stmt->fetch();
        $stmt->close();

        // Part where delete if cease to exist (only in database NOT THE ACTUAL FILE)
        if (!empty($image) && file_exists("uploads/" . $image)) {
            unlink("uploads/" . $image);
        }

        // Delete the product details in database
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        header("Location: manageproducts.php"); // Refresh the page
        exit();
    }

    //Fetch/Get the products
    $result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="manageproducts.css">
    <script>
    function confirmDelete(id) {
        if (confirm("Are you sure you want to delete this product?")) {
            window.location.href = "manageproducts.php?delete=" + id;
        }
    }
    </script>
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk</h1>
        </div>
        <ul>
            <li><a href="manageproducts.php" class="disabled"><img src="assets/i_shopping-cart.svg"> Product Management</a></li>
            <li><a href="admin.php"><img src="assets/i_cpu.svg"> Admin Panel</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <div class="maincontainer">
                <h3>Add a Product</h3>
                <div class="addproduct">
                    <form method="POST" enctype="multipart/form-data">
                        <input type="text" name="name" placeholder="Product Name" required>
                        <input type="number" name="price" placeholder="Price" required step="0.01">
                        <input type="file" name="image" required>
                        <button type="submit" name="add_product">Add Product</button>
                    </form>
                </div>

                <h3>Manage Products</h3>
                <table cellspacing="16px">
                    <tr>
                        <th width="160px">Image</th>
                        <th width="170px">Name</th>
                        <th width="70px">Price</th>
                        <th width="100px">Action</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><img src="uploads/<?php echo $row['image']; ?>" width="150px"></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td>&#8369;<?php echo number_format($row['price'], 2); ?></td>
                        <td>
                            <button type="button" onclick="confirmDelete(<?php echo $row['id']; ?>)">Delete</button>
                        </td>
                    <?php endwhile; ?>
                    </tr>
                </table>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>