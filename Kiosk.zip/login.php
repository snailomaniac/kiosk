<?php
    session_start();

    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        if ($username === "admin" && $password === "admin") {
            $_SESSION['user_id'] = "admin";
            $_SESSION['username'] = "admin";
            header("Location: admin.php");
            exit();
        }

        $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($user_id, $hashed_password);

        if ($stmt->fetch()) {
            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $user_id; // Set user_id in session
                $_SESSION['username'] = $username;
                header('Location: store.php');
                exit();
            } else {
                error_log("Failed login attempt for username: $username");
                header('Location: form.php?error=invalid_credentials');
                exit();
            }
        } else {
            error_log("Failed login attempt with non-existent username: $username");
            header('Location: form.php?error=invalid_credentials');
            exit();
        }

        $stmt->close();
    } else {
        header('Location: form.php');
        exit();
    }
    
    $conn->close();
?>