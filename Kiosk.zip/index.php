<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk</h1>
        </div>
        <ul>
            <li><a href="index.php" class="disabled"><img src="assets/i_home.svg"> Home</a></li>
            <li><a href="form.php"><img src="assets/i_log-in.svg"> Login</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <div class="maincontainer">
                <div>
                    <h1>Welcome to Palengke Kiosk!</h1>
                    <p>Palengke Kiosk is a simple online store where you can buy your favorite products. You can browse through our products and add them to your cart. You can also view your cart and manage your orders.</p>
                    <a href="login.php" class="button">Browse Products <img src="assets/i_shopping-cart.svg"></a>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>