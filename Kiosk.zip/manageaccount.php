<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskdb");

    if ($conn->connect_error) {
        die("connection failed: " . $conn->connect_error);
    }

    if (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $conn->query("DELETE FROM users WHERE id=$id");
    }

    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $username = $_POST['username'];
        $conn->query("UPDATE users SET username='$username' WHERE id=$id");
    }

    if (isset($_POST['add'])) {
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $conn->query("INSERT INTO users (username, password) VALUES ('$username', '$password')");
    }

    $sql = "SELECT id, username FROM users";
    $result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Management | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="manageaccount.css">
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk</h1>
        </div>
        <ul>
            <li><a href="manageaccount.php" class="disabled"><img src="assets/i_user.svg"> Account Management</a></li>
            <li><a href="admin.php"><img src="assets/i_cpu.svg"> Admin Panel</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <div class="maincontainer">
                <h3>Manage Account</h3>
                <table cellspacing="16px">
                    <tr>
                        <th width="16px">ID</th>
                        <th width="180px">Username</th>
                        <th width="100px">Actions</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <form method="post">
                                <td align="center"><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><input type="text" name="username" value="<?php echo htmlspecialchars($row['username']); ?>"></td>
                                <td align="center">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                    <button type="submit" class="update" name="update">Update</button><br>
                                    <button type="submit" class="delete" name="delete" onclick="return confirm('Are you sure?');">Delete</button>
                                </td>
                            </form>
                        </tr>
                    <?php endwhile; ?>
                </table>

                <div class="addaccount">
                    <h3>Add an Account</h3>
                    <form method="post">
                        <input type="text" name="username" placeholder="Username" required>
                        <input type="password" name="password" placeholder="Password" required>
                        <button type="submit" name="add">Add account</button>
                    </form>
                </div>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>
<?php $conn->close(); ?>