<?php
    session_start();
    $conn = new mysqli("localhost", "root", "", "kioskDB");

    if ($conn->connect_error) {
        die("Connection Failed: " . $conn->error);
    }

    // Update and Handle the orders
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_order'])) {
        $order_id = $_POST['order_id'];
        $status = $_POST['status'];
        
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $order_id);
        if ($stmt->execute()) {
            echo json_encode(["status" => true]);
        } else {
            echo json_encode(["status" => false, "error" => $stmt->error]);
        }
        $stmt->close();
        exit();
    }
    
    // Handle order deletion
    if (isset($_GET['delete_order'])) {
        $order_id = $_GET['delete_order'];

        $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->bind_param("i", $order_id);
        if ($stmt->execute()) {
            echo "<script>alert('Order deleted!'); window.location.href='manageorders.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    
    // Fetch all the orders
    $result = $conn->query("SELECT orders.*, products.name AS product_name FROM orders
                            JOIN products ON orders.product_id = products.id
                            ORDER BY order_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management | Kiosk</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="manageorder.css">
    <script>
        function updateStatus(orderId, status) {
            let formData = new formData();
            formData.append('order_id', order_id);
            formData.append('status', status);
            formData.append('update_order', '1');

            fetch("manageorders.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert("Order status updated successfully!");
                } else {
                    alert("Error update order: " + data.error);
                }
            })
            .catch(error => console.error("Error:", error));
        }
    </script>
</head>
<body>
    <nav>
        <div class="left-nav">
            <img src="assets/i_map-pin.svg"> <h1>Palengke Kiosk</h1>
        </div>
        <ul>
            <li><a href="manageorders.php" class="disabled"><img src="assets/i_user.svg"> Order Management</a></li>
            <li><a href="admin.php"><img src="assets/i_cpu.svg"> Admin Panel</a></li>
            <li><a href="logout.php"><img src="assets/i_log-out.svg"> Log out</a></li>
        </ul>
    </nav>
    
    <main>
        <section>
            <div class="maincontainer">
                <h3>Manage Orders</h3>
                <table cellspacing="16px">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>User ID</th>
                            <th>Product</th>
                            <th>Full Name</th>
                            <th>Address</th>
                            <th>Contact</th>
                            <th>Payment</th>
                            <th>Order Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['user_id']; ?></td>
                            <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['address']); ?></td>
                            <td><?php echo htmlspecialchars($row['contact']); ?></td>
                            <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                            <td><?php echo $row['order_date']; ?></td>
                            <td>
                                <select name="status" onchange="updateStatuse(<?php echo $row[$id]; ?>, this.value)">
                                    <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                    <option value="Processing" <?php if ($row['status'] == 'Processing') echo 'selected'; ?>>Processing</option>
                                    <option value="Shipped" <?php if ($row['status'] == 'Shipped') echo 'selected'; ?>>Shipped</option>
                                    <option value="Delivered" <?php if ($row['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                                    <option value="Complete" <?php if ($row['status'] == 'Complete') echo 'selected'; ?>>Complete</option>
                                    <option value="Cancelled" <?php if ($row['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                                </select>
                            </td>
                            <td>
                                <button onclick="location.href='manageorders.php?delete_order=<?php echo $row['id']; ?>'; return confirm('are you sure you want to delete this order?')">Delete</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
    
    <footer>
        <p>&copy; 2025 - Kiosk by James Marku Alarcon</p>
    </footer>
</body>
</html>